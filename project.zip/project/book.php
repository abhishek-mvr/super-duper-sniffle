<?php
echo $_SESION['j_id'];
?>
