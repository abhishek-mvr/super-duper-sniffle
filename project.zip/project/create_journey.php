<form method="post" action="insert_journey.php">
  Starting location<br>
  <input type="text" name="start"><br>
  Destination<br>
  <input type="text" name="finish"><br>
  date<br>
  <input type="text" name="date"><br>
  starting time<br>
  <input type="text" name="time"><br>
  fare per seat<br>
  <input type="text" name="fare"><br>
<input type="checkbox" name="AC" value="Car" checked="checked">AC?<br>
Ride Description<br>
<input type="textarea" name="rdesc"><br>
<input type="submit" value="put it">
</form>
