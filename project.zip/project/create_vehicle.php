

<form method="post" action="insert_vehicle.php">
  Model name<br>
  <input type="text" name="mname"><br>
  Registration no:<br>
  <input type="text" name="rno"><br>
  Vehicle Description<br>
  <input type="textarea" name="vdesc"><br>
  <input type="submit" value="put it">
</form>
